﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace TOURISUM_MANAGEMENT_SYSTEM
{
    public partial class Booking : Form
    {
        SqlConnection x = new SqlConnection(@"Data Source=DESKTOP-5IKMSD5\SQLEXPRESS02;Initial Catalog=tourisum06;Integrated Security=True");

        public Booking()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home hh = new Home();
            hh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            te1.Clear();
            te2.Clear();
            te3.Clear();
            te4.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string insert;
            insert = "insert into booking(bo_id,cu_id,bo_date,pa_status)values('" + te1.Text + "','" + te2.Text + "','" + te3.Text + "','" + te4.Text + "')";
            SqlCommand xx = new SqlCommand(insert, x);
            x.Open();
            xx.ExecuteNonQuery();
            MessageBox.Show("Record Added Succesfully");

            te1.Clear();
            te2.Clear();
            te3.Clear();
            te4.Clear();

            x.Close();
        }

        private void te3_TextChanged(object sender, EventArgs e)
        {

        }

        private void te1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Delete;
            Delete =" Delete from booking where bo_id='"+te1.Text+"' ";
            SqlCommand xx = new SqlCommand(Delete, x);
            x.Open();
            xx.ExecuteNonQuery();

            MessageBox.Show("Record Delete Succesfully");

            te1.Clear();
            te2.Clear();
            te3.Clear();
            te4.Clear();

            x.Close();
        
        
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string SQLsearch;
                SQLsearch = "select * from Booking where bo_id ='" + te1.Text + "'";
                SqlCommand xx = new SqlCommand(SQLsearch, x);
                x.Open();
                SqlDataReader dr = xx.ExecuteReader();
                if (dr.Read())
                {
                    te2.Text = dr["cu_id"].ToString();
                    te3.Text = dr["bo_date"].ToString();
                    te4.Text = dr["pa_status"].ToString();

                }
                else
                {
                    MessageBox.Show("Emp not found");

                }
                x.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string Update;
            Update = " Update booking set bo_id ='" + te1.Text + "',cu_id='" + te2.Text + "',bo_date='" + te3.Text + "',pa_status='" + te4.Text + "' ";
            SqlCommand xx = new SqlCommand(Update, x);
            x.Open();
            xx.ExecuteNonQuery();
            MessageBox.Show("Record Update succesfully");

            te1.Clear();
            te2.Clear();
            te3.Clear();
            te4.Clear();


            x.Close();

        }
    }

}