﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace TOURISUM_MANAGEMENT_SYSTEM
{
    public partial class Payment : Form
    {
        SqlConnection x = new SqlConnection(@"Data Source=DESKTOP-5IKMSD5\SQLEXPRESS02;Initial Catalog=tourisum06;Integrated Security=True");

        public Payment()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home hh = new Home();
            hh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string insert;
            insert = "insert into payment (pa_id,cu_id,pa_date,pa_method)values('" + t1.Text + "','" + t2.Text + "','" + t3.Text + "','" + t4.Text + "')";
            SqlCommand xx = new SqlCommand(insert, x);
            x.Open();
            xx.ExecuteNonQuery();
            MessageBox.Show("Record Added Succesfully");

            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();

            x.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Delete;
            Delete = "delete from Payment where pa_id='" + t1.Text + "'";
            SqlCommand xx = new SqlCommand(Delete, x);
            x.Open();
            xx.ExecuteNonQuery();
            MessageBox.Show("Delete Added succesfully");

            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();

            x.Close();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string Search;
                Search = "select * from payment where pa_id='" + t1.Text + "'";
                SqlCommand xx = new SqlCommand(Search, x);

                x.Open();
                SqlDataReader dr = xx.ExecuteReader();
                if (dr.Read())
                {
                    t1.Text =dr ["pa_id"].ToString();
                    t2.Text = dr["cu_id"].ToString();
                    t3.Text = dr["pa_date"].ToString();
                    t4.Text = dr["pa_method"].ToString();
                }
                else
                {
                    MessageBox.Show("Emp not found");
                }
                
                x.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string Update;
            Update = " Update Payment set pa_id='" + t1.Text + "',cu_id='" + t2.Text + "',pa_date='" + t3.Text + "',pa_method='" + t4.Text + "' ";
            SqlCommand xx = new SqlCommand(Update, x);
            x.Open();
          
            xx.ExecuteNonQuery();

            MessageBox.Show("Record Update Succesfully");
            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();
     

            x.Close();

        }
    }
}