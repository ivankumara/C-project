﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOURISUM_MANAGEMENT_SYSTEM
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Custome hh = new Custome();
            hh.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking hh = new Booking();
            hh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
             this.Hide();
            Payment hh = new Payment();
            hh.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();


        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Hotel hh = new Hotel();
            hh.Show();
        }

    
        
    


        }

        }
    

