﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace TOURISUM_MANAGEMENT_SYSTEM
{
    public partial class Custome : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5IKMSD5\SQLEXPRESS02;Initial Catalog=tourisum06;Integrated Security=True");


        public Custome()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home hh = new Home();
            hh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tx1.Clear();
            tx2.Clear();
            tx3.Clear();
            tx4.Clear();
            tx5.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            string sqlInsert;
            sqlInsert = "insert into customer (cu_id ,cu_name ,cu_email,cu_contact,cu_address)values('" + tx1.Text + "','" + tx2.Text + "','" + tx3.Text + "','" + tx4.Text + "','" + tx5.Text+ "')";
            SqlCommand cmd = new SqlCommand(sqlInsert, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Added Succesfully");
            tx1.Clear();
            tx2.Clear();
            tx3.Clear();
            tx4.Clear();
            tx5.Clear();
            con.Close();

        }
        


        private void button4_Click(object sender, EventArgs e)
        {
            string update;
            update = "update Customer set cu_id ='" + tx1.Text + "',cu_name='" + tx2.Text + "',cu_email='" + tx3.Text + "',cu_contact='" + tx4.Text + "',cu_address='" + tx5.Text + "' ";
            SqlCommand cmd = new SqlCommand(update, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Update Succesfully");
            tx1.Clear();
            tx2.Clear();
            tx3.Clear();
            tx4.Clear();
            tx5.Clear();


            con.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlDelete;
            sqlDelete = "Delete from Customer where cu_id='" + tx1.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlDelete, con);
            con.Open();
            cmd.ExecuteNonQuery();

            MessageBox.Show("Record Delete Succesfully");
            tx1.Clear();
            tx2.Clear();
            tx3.Clear();
            tx4.Clear();
            tx5.Clear();

            con.Close();


        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string SQLsearch;
                SQLsearch = "select * from customer where cu_id='" + tx1.Text + "'";
                SqlCommand cmd = new SqlCommand(SQLsearch, con);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    tx2.Text = dr["cu_name"].ToString();
                    tx3.Text = dr["cu_email"].ToString();
                    tx4.Text = dr["cu_contact"].ToString();
                    tx5.Text = dr["cu_address"].ToString();
                }
                else
                {
                    MessageBox.Show("Emp not found");

                }
                con.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }
    }
}
