﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOURISUM_MANAGEMENT_SYSTEM
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                string user = textBox1.Text;
                string pass = textBox2.Text;

                if (user == "rathnayaka" && pass == "123")
                {
                    this.Hide();
                    this.Hide();
                    Home hh = new Home();
                    hh.Show();
                }
                else
                {
                    MessageBox.Show("Login not Success");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
