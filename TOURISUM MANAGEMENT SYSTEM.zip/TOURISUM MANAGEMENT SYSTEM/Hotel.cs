﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace TOURISUM_MANAGEMENT_SYSTEM
{
    public partial class Hotel : Form
    {
        SqlConnection x = new SqlConnection(@"Data Source=DESKTOP-5IKMSD5\SQLEXPRESS02;Initial Catalog=tourisum06;Integrated Security=True");

        public Hotel()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home hh = new Home();
            hh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tex1.Clear();
            tex2.Clear();
            tex3.Clear();
            tex4.Clear();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string insert;
            insert = "insert into hotel(ho_id,ho_name,contact,ho_location)values('" + tex1.Text + "','" + tex2.Text + "','" + tex3.Text + "','" + tex4.Text + "')";
            SqlCommand xx = new SqlCommand(insert, x);
            x.Open();
            xx.ExecuteNonQuery();
            MessageBox.Show("Record Added Succesfully");

            tex1.Clear();
            tex2.Clear();
            tex3.Clear();
            tex4.Clear();

            x.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Delete;
            Delete = "Delete from Hotel where ho_id='" + tex1.Text + "'";
            SqlCommand xx = new SqlCommand(Delete ,x);
            x.Open();
            xx.ExecuteNonQuery();
            MessageBox.Show("Record Delete succesfully");

            tex1.Clear();
            tex2.Clear();
            tex3.Clear();
            tex4.Clear();

            x.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string search;
                search ="Select * from Hotel where ho_id='" + tex1.Text + "'";
                SqlCommand xx = new SqlCommand(search ,x);
                x.Open();
                SqlDataReader dr = xx.ExecuteReader();
                if (dr.Read())
                {

                    tex2.Text = dr["ho_name"].ToString();
                    tex3.Text = dr["contact"].ToString();
                    tex4.Text = dr["ho_location"].ToString();
                }
                else
                {
                    MessageBox.Show("Emp not found");
                }

                x.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string Update;
            Update = " Update Hotel set ho_id ='" + tex1.Text + "',ho_name='" + tex2.Text + "',contact='" + tex3.Text + "',ho_location='" + tex4.Text + "' ";
            SqlCommand xx = new SqlCommand(Update, x);
            x.Open();
            xx.ExecuteNonQuery();
            MessageBox.Show("Record Update succesfully");

            tex1.Clear();
            tex2.Clear();
            tex3.Clear();
            tex4.Clear();

            x.Close();








        }

        private void tex4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
